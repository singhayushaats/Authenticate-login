/*You are playing a fun game. Your favorite character, Seele, is very strong. She can kill monsters in either '1' or '2' attacks.
There are 'N' monsters ready to fight. You are given an array 'A' of length 'N' such that 'A[ i ]' represents the number of attacks Seele takes to kill the 'i-th' enemy.
Seele and the monsters take turns attacking. They attack once per turn. The damage dealt by the monsters to Seele is negligible. Each attack from Seele only targets one monster.
Seele also has a unique ability. If she kills a monster, she gets to attack again in the same turn. However, if the second attack kills another monster, Seele does not get another extra attack.
Return the minimum number of turns Seele takes to kill all the monsters.*/